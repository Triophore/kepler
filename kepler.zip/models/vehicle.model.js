module.exports = {
    name:'vehicle',
    schema:{
        vehicle_type:{
            type:String,
            required:true
        },
        vehicle_number:{
            type:String,
            required:true
        },
        
    }
}