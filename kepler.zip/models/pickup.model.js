module.exports = {
    name:'pickup',
    schema:{
        name:{
            type:String
        }
    }
}