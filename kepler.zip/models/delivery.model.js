/** @module Models:Delievry */
module.exports = {
    name:'delivery',
    schema:{
        name:{
            type:String
        }
    },
    plugin:{

    },
    form:{
        
    }
}