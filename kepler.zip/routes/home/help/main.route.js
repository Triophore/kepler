module.exports = {
    method: 'GET',
    path: '/get4',
    handler: (request, h) => {

        return 'Hello World!4';
    }
}