module.exports = {
  method: 'GET',
  path: '/get2',
  handler: (request, h) => {

      return 'Hello World!2';
  }
}